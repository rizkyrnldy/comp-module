import React from 'react';

type Props = {
  title: any;
};

const MyComponent: React.FC<Props> = ({ title }: any) => {
  return {title};
};

export default MyComponent;